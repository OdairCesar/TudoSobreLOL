<html>
    <head>
        <meta charset="utf8">
        <meta name="author" content="Odair Cesar">
        <meta name="description" content="Saiba o que muito do League Of Legends nesse ultimo patch em video ou em artigo. Campeões ficaram roubados, itens que perderam valor o modo rotativo e muito mais.">
        <title>Informações sobre as mudança do ultimo Patch</title>
        <link rel="stylesheet" type="text/css" href="../estilo.css">
        <link rel="stylesheet" type="text/css" href="../fontes.css">
        <link rel="shortcut icon" href="../imagens/logo-lol.jpg">
        <?php
            include_once '../class/Pagina.php';
            $noturl = isset($_GET['var'])? $_GET['var'] : 0;
        ?>
    </head>
    <body>
        <?php
            $pagina = new Pagina("Atualizacao", $noturl);
        ?>
    </body>
</html>


