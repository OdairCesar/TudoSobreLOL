<html>
    <head>
        <meta charset="utf8">
        <meta name="author" content="Odair Cesar">
        <meta name="description" content="Zueras da Semana no LOL, League Of Legends paras cultos ou Lolzinho para gafanhotos transandes. Todas as farpas e falhas dos pro-playes e streamers que ocorreram ao longo dos ultimos 3 dias. Além das melhores e piores jogadas que ocorreram no CBLOL">
        <link rel="stylesheet" type="text/css" href="../estilo.css">
        <link rel="stylesheet" type="text/css" href="../fontes.css">
        <link rel="shortcut icon" href="../imagens/logo-lol.jpg">
        <title>Veja por os streamers e jogadores estão sendo zuados</title>
        <?php
            include_once '../class/Pagina.php';
            $noturl = isset($_GET['var'])? $_GET['var'] : 0;
        ?>
    </head>
    <body>
        <?php
            $pagina = new Pagina("Zoera", $noturl);
        ?>
    </body>
</html>


